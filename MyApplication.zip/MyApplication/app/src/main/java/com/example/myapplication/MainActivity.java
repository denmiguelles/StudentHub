package com.example.myapplication;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        // Courses Button
        CardView coursesButton = findViewById(R.id.coursesButton);

        coursesButton.setOnClickListener(v -> {
            Toast.makeText(
                    MainActivity.this,
                    "Courses clicked!",
                    Toast.LENGTH_SHORT
            ).show();
        });

        // Assignments Button
        CardView assignmentsButton = findViewById(R.id.assignmentsButton);

        assignmentsButton.setOnClickListener(v -> {
            Toast.makeText(
                    MainActivity.this,
                    "Assignments clicked!",
                    Toast.LENGTH_SHORT
            ).show();
        });

        // My Schedule Button
        CardView scheduleButton = findViewById(R.id.scheduleButton);

        scheduleButton.setOnClickListener(v -> {
            Toast.makeText(
                    MainActivity.this,
                    "My Schedule clicked!",
                    Toast.LENGTH_SHORT
            ).show();
        });

        // Dashboard Button
        Button superButton = findViewById(R.id.superButton);

        superButton.setOnClickListener(v -> {
            Toast.makeText(
                    MainActivity.this,
                    "Dashboard clicked!",
                    Toast.LENGTH_SHORT
            ).show();
        });
    }
}