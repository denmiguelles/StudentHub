package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mAuth = FirebaseAuth.getInstance();

        // Check if user is logged in
        if (mAuth.getCurrentUser() == null) {
            openLogin();
            return;
        }

        setContentView(R.layout.activity_main);

        // Courses Button
        CardView coursesButton = findViewById(R.id.coursesButton);

        coursesButton.setOnClickListener(v -> {
            Toast.makeText(
                    MainActivity.this,
                    "Courses clicked!",
                    Toast.LENGTH_SHORT
            ).show();
        });

        // Assignments Button
        CardView assignmentsButton = findViewById(R.id.assignmentsButton);

        assignmentsButton.setOnClickListener(v -> {
            Toast.makeText(
                    MainActivity.this,
                    "Assignments clicked!",
                    Toast.LENGTH_SHORT
            ).show();
        });

        // My Schedule Button
        CardView scheduleButton = findViewById(R.id.scheduleButton);

        scheduleButton.setOnClickListener(v -> {
            Toast.makeText(
                    MainActivity.this,
                    "My Schedule clicked!",
                    Toast.LENGTH_SHORT
            ).show();
        });

        // Dashboard Button
        Button superButton = findViewById(R.id.superButton);

        superButton.setOnClickListener(v -> {
            Toast.makeText(
                    MainActivity.this,
                    "Dashboard clicked!",
                    Toast.LENGTH_SHORT
            ).show();
        });

        // Logout Button
        Button logoutButton = findViewById(R.id.logoutButton);

        logoutButton.setOnClickListener(v -> {
            mAuth.signOut();

            Toast.makeText(
                    MainActivity.this,
                    "Logged out successfully!",
                    Toast.LENGTH_SHORT
            ).show();

            openLogin();
        });
    }

    private void openLogin() {
        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}